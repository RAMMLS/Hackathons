
![[timings.png]]


